package com.example.education;

public class product {
	String id;
    String name;
    boolean box;
    

    product(String _id, String _name, boolean _box) {
      id = _id;
      name = _name;
      box = _box;
    }

}
