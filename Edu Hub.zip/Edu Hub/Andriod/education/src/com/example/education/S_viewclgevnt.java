package com.example.education;

import java.util.ArrayList;
import java.util.HashMap;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.TargetApi;
import android.app.Activity;
import android.view.Menu;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class S_viewclgevnt extends Activity {
ListView a;
	@TargetApi(Build.VERSION_CODES.GINGERBREAD) @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_s_viewclgevnt);
		 try
	    	{
	    		if (android.os.Build.VERSION.SDK_INT > 9) 
	    		{
	    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	    			StrictMode.setThreadPolicy(policy);
	    		}
	    	}
	    	catch(Exception e)
	    	{
	    	
	    	}
		a=(ListView)findViewById(R.id.listView1);
		SoapObject obj=new SoapObject(soapclass.NAMESPACE, "event_act");
		soapclass sc=new soapclass();
		String ou=sc.Callsoap(obj, "http://tempuri.org/event_act");
		if(!ou.equals("error" ) && !ou.equals(""))
		{
			try
			{
			ArrayList<HashMap<String,String>> allist= new ArrayList<HashMap<String,String>>();
			String[] s1 = ou.split("@");
			for (int i=0;i<s1.length;i++){
				String[] s2= s1[i].split("#");
				HashMap<String, String> hmap=new HashMap<String, String>();
				hmap.put("a", s2[0]);
				hmap.put("b", s2[1]);
				hmap.put("c",s2[2]);
				hmap.put("d", s2[3]);
				hmap.put("e", s2[4]);
				allist.add(hmap);
			
			}
			ListAdapter lis=new SimpleAdapter(S_viewclgevnt.this, allist, R.layout.clgevt, new String[] {"a","b","c","d","e"}, new int[] {R.id.textView6,R.id.textView7,R.id.textView8,R.id.textView9,R.id.textView10});
			a.setAdapter(lis);
			}catch (Exception e) {
				// TODO: handle exception
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		
		getMenuInflater().inflate(R.menu.s_viewclgevnt, menu);
		return true;
	}

}
