package com.example.education;



import java.util.ArrayList;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.TextView;

public class ListAdapter extends BaseAdapter {
    Context ctx;
    LayoutInflater lInflater;
    ArrayList<product> objects;

    ListAdapter(Context context, ArrayList<product> products) {
        ctx = context;
        objects = products;
        lInflater = (LayoutInflater) ctx
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return objects.size();
    }

    @Override
    public Object getItem(int position) {
        return objects.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = lInflater.inflate(R.layout.education, parent, false);
        }

        product p = getProduct(position);

        ((TextView) view.findViewById(R.id.textView2)).setText(p.id);
        ((TextView) view.findViewById(R.id.textView1)).setText(p.name);
        

        CheckBox cbBuy = (CheckBox) view.findViewById(R.id.checkBox1);
        cbBuy.setOnCheckedChangeListener(myCheckChangList);
        cbBuy.setTag(position);
        cbBuy.setChecked(p.box);
        return view;
    }

    product getProduct(int position) {
        return ((product) getItem(position));
    }

    ArrayList<product> getBox() {
        ArrayList<product> box = new ArrayList<product>();
        for (product p : objects) {
            if (p.box)
            {
                box.add(p);
            }
            else
            {
            	box.add(p);
            }
        }
        
        return box;
    }

    OnCheckedChangeListener myCheckChangList = new OnCheckedChangeListener() {
        public void onCheckedChanged(CompoundButton buttonView,
                boolean isChecked) {
            getProduct((Integer) buttonView.getTag()).box = isChecked;
        }
    };
}
