package com.example.education;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

@SuppressLint("NewApi") @TargetApi(Build.VERSION_CODES.GINGERBREAD) public class Forgotpass extends Activity {
	EditText a;
	Button b;
	@SuppressLint("NewApi") @TargetApi(Build.VERSION_CODES.GINGERBREAD) @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_forgotpass);
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
		a=(EditText)findViewById(R.id.editText1);
		b=(Button)findViewById(R.id.button1);
		
		b.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				String emlpattern="[a-zA-Z0-9._-]+@gmail+\\.+com+";
//				if(!a.getText().toString().matches(emlpattern))
//				{
//					Toast.makeText(getApplicationContext(), "Enter valid email", 3).show();
//					a.setText("");
//				}
				
				if(!a.getText().toString().equals(""))
				{
				
				SoapObject obj=new SoapObject(soapclass.NAMESPACE, "forgot_act");
				obj.addProperty("ml", a.getText().toString());
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj,"http://tempuri.org/forgot_act");
				
				if(!ou.equals("error")&&!ou.equals(""))
				{
					a.setText("");
					
					Toast.makeText(getApplicationContext(), "success", 3).show();
				}
				
				
			}
			
				else
				{
					Toast.makeText(getApplicationContext(), "Enter Email_id", 3).show();
				}
		
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.forgotpass, menu);
		return true;
	}

}
