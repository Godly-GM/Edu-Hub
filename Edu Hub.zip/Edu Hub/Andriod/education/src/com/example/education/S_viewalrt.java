package com.example.education;

import java.util.ArrayList;
import java.util.HashMap;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.TargetApi;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;

public class S_viewalrt extends Activity {
ListView a;
	@TargetApi(Build.VERSION_CODES.GINGERBREAD) @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_s_viewalrt);
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
		a=(ListView)findViewById(R.id.listView1);
		SoapObject obj=new SoapObject(soapclass.NAMESPACE, "Alertview_act");
		obj.addProperty("pid", Login.uid);
		soapclass sc=new soapclass();
		String ou=sc.Callsoap(obj,"http://tempuri.org/Alertview_act");
		if(!ou.equals("error" ) && !ou.equals(""))
		{
			try
			{
			ArrayList<HashMap<String,String>> allist= new ArrayList<HashMap<String,String>>();
			String[] s1 = ou.split("@");
			for (int i=0;i<s1.length;i++){
				String[] s2= s1[i].split("#");
				HashMap<String, String> hmap=new HashMap<String, String>();
				hmap.put("a", s2[0]);
				hmap.put("b", s2[1]);
				
				allist.add(hmap);
			
			}
			ListAdapter lis=new SimpleAdapter(S_viewalrt.this, allist, R.layout.alrt, new String[] {"a","b"}, new int[] {R.id.textView3,R.id.textView4});
			a.setAdapter(lis);
			}catch (Exception e) {
				// TODO: handle exception
			}
	}}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.s_viewalrt, menu);
		return true;
	}

}
