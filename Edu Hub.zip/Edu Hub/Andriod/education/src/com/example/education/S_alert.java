package com.example.education;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

@SuppressLint("NewApi") public class S_alert extends Activity {
EditText a;
Button b;
Spinner c;
	@SuppressLint("NewApi") @TargetApi(Build.VERSION_CODES.GINGERBREAD) @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_s_alert);
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
		a=(EditText)findViewById(R.id.editText1);
		b=(Button)findViewById(R.id.button1);
		c=(Spinner)findViewById(R.id.spinner1);
		b.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(!a.getText().toString().equals("")&& (!c.getSelectedItem().toString().equals("")))
				{
				if(!c.getSelectedItem().toString().equals("select"))
				{
				SoapObject obj=new SoapObject(soapclass.NAMESPACE, "Alert_act");
				obj.addProperty("staff_id",Login.uid);
				obj.addProperty("alert", a.getText().toString());
				obj.addProperty("sem",c.getSelectedItem().toString());
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj,"http://tempuri.org/Alert_act");
				Toast.makeText(getApplicationContext(), ou, 3).show();
				a.setText("");
				}
				else
				{
					Toast.makeText(getApplicationContext(), "choose semester", 3).show();
				}
			}
			
			else
			{
				Toast.makeText(getApplicationContext(), "Enter Alert And Select Semester", 3).show();
			}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		
		
		getMenuInflater().inflate(R.menu.s_alert, menu);
		return true;
	}

}
