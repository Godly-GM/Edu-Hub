package com.example.education;

import java.util.ArrayList;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

public class S_attndc extends Activity {
ListView a;
Button b;
Spinner c,d;
ArrayList<product> products = new ArrayList<product>();
ListAdapter boxAdapter;

    @SuppressLint("NewApi") @TargetApi(Build.VERSION_CODES.GINGERBREAD) @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_attndc);
        try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
        c=(Spinner)findViewById(R.id.spinner1);
        d=(Spinner)findViewById(R.id.spinner2);
        a=(ListView)findViewById(R.id.listView1);
        b=(Button)findViewById(R.id.button1);
        c.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				if(!c.getSelectedItem().toString().equals("select"))
				{
					try
					{
				fillData(c.getSelectedItem().toString());
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
        b.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				showResult();
				
				
			}
		});
    }
    
    
    void fillData(String sem) {
    	SoapObject sobj=new SoapObject(soapclass.NAMESPACE,"students");
    	sobj.addProperty("Semester", sem);
		soapclass sc=new soapclass();
		String ou=sc.Callsoap(sobj, "http://tempuri.org/students");
		
		String []s1=ou.split("@");
		String[] id=new String[s1.length];
		String[] name=new String[s1.length];
		for(int i=0;i<s1.length;i++)
		{
			String []s2=s1[i].split("#");
			id[i]=s2[0];
			name[i]=s2[1];
			 products.add(new product(s2[0], s2[1],false));
		}
        boxAdapter = new ListAdapter(this, products);
        a.setAdapter(boxAdapter);

    }

    

    public void showResult() {
     if(!d.getSelectedItem().toString().equals("select"))
     {
        for (product p : boxAdapter.getBox()) {
        	String sts;
        
          if (p.box){
           sts="present";
          }
          else
          {
        	  sts="absent";
          }
            SoapObject sobj=new SoapObject(soapclass.NAMESPACE,"Attendance_act");
            sobj.addProperty("Stu_id", p.id);
            sobj.addProperty("Status", sts);
            sobj.addProperty("Hour", d.getSelectedItem().toString());
            sobj.addProperty("Staff_id", Login.uid);
    		soapclass sc=new soapclass();
    		String ou=sc.Callsoap(sobj, "http://tempuri.org/Attendance_act");
         
        }
        Intent i=new Intent(getApplicationContext(),Staff_home.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(i);
     }else
     {
    	 Toast.makeText(getApplicationContext(), "choose hour", 3).show();
     }
      // Toast.makeText(getApplicationContext(), ou, duration)
      }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.s_attndc, menu);
        return true;
    }
    
}
