package com.example.education;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class S_addfeedbck extends Activity {
EditText a;
Button b;
	@SuppressLint("NewApi") @TargetApi(Build.VERSION_CODES.GINGERBREAD) @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_s_addfeedbck);
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
		a=(EditText)findViewById(R.id.editText1);
		b=(Button)findViewById(R.id.button1);
		b.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(!a.getText().toString().equals(""))
				{
				
				SoapObject sobj=new SoapObject(soapclass.NAMESPACE,"feedback_id");
				sobj.addProperty("User_id", Login.uid);
				sobj.addProperty("feedback",a.getText().toString());
				
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(sobj,"http://tempuri.org/feedback_id");
				if(!ou.equals("")&&!ou.equals("error"))
				{
					Toast.makeText(getApplication(), "success",3).show();
				}
				
				Intent i=new Intent(getApplicationContext(),Parnt_home.class);
				startActivity(i);
				
			}
			else
			{
				Toast.makeText(getApplicationContext(), "Enter Feedback", 3).show();
			}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.s_addfeedbck, menu);
		return true;
	}

}
