package com.example.education;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import org.ksoap2.serialization.SoapObject;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.StrictMode;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

public class TimeService extends Service {

	// constant
	public static final long NOTIFY_INTERVAL = 20 * 1000; // 10 seconds

	private NotificationManager alarmNotificationManager;
	// run on another Thread to avoid crash
	private Handler mHandler = new Handler();
	// timer handling
	private Timer mTimer = null;
	
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {

		// cancel if already existed
		if (mTimer != null) {
			mTimer.cancel();
		} else {
			// recreate new
			mTimer = new Timer();
		}
		// schedule task
		mTimer.scheduleAtFixedRate(new TimeDisplayTimerTask(), 0,
				NOTIFY_INTERVAL);
	}

	@TargetApi(Build.VERSION_CODES.GINGERBREAD)
	class TimeDisplayTimerTask extends TimerTask {

		@Override
		public void run() {
			// run on another thread
			mHandler.post(new Runnable() {
				@Override
				public void run() {
					//Toast.makeText(getApplicationContext(), "hello", 5).show();
					if(Login.ty.equals("parent"))
					{
					SoapObject obj = new SoapObject(soapclass.NAMESPACE, "Parent_alertview_act");
					soapclass sc = new soapclass();
					obj.addProperty("pid", Login.uid);
					String ou = sc.Callsoap(obj, "http://tempuri.org/Parent_alertview_act");
					if(!ou.equals("") && !ou.equals("error"))
					{
						Notification(ou);
					}
					}
				}
			});
		}
	}

	
	private void Notification(String msg) {

		alarmNotificationManager = (NotificationManager) this
				.getSystemService(Context.NOTIFICATION_SERVICE);
		PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
				new Intent(this, Login.class), 0);

		NotificationCompat.Builder alamNotificationBuilder = new NotificationCompat.Builder(
				this).setContentTitle(msg)
				.setSmallIcon(R.drawable.ic_launcher)
				.setStyle(new NotificationCompat.BigTextStyle().bigText(msg)); //
		alamNotificationBuilder.setContentIntent(contentIntent);
		alarmNotificationManager.notify(0, alamNotificationBuilder.build());

	}

	

	

}

// In manifest
// <service android:name="com.example.bus.TimeService" >
// </service>

// In main page
// startService(new //Intent(getApplicationContext(),TimeService.class));