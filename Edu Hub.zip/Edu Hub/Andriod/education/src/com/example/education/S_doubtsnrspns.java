package com.example.education;

import java.util.ArrayList;
import java.util.HashMap;

import org.ksoap2.serialization.SoapObject;

import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Toast;

@SuppressLint("NewApi") public class S_doubtsnrspns extends Activity {
ListView a;
EditText b;
Button c;
Spinner d;
String staffid;
String []st_id;
String []st_nm;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_s_doubtsnrspns);
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
		a=(ListView)findViewById(R.id.listView1);
		b=(EditText)findViewById(R.id.editText1);
		c=(Button)findViewById(R.id.button1);
		d=(Spinner)findViewById(R.id.spinner1);
		SoapObject obj=new SoapObject(soapclass.NAMESPACE, "staff");
		soapclass sc=new soapclass();
		String ou=sc.Callsoap(obj,"http://tempuri.org/staff");
		//Toast.makeText(getApplicationContext(), ou, 3).show();
		if(!ou.equals("") && !ou.equals("error"))
		{
			String []s=ou.split("@");
			st_id =new String[s.length];
			st_nm =new String[s.length];
			//Toast.makeText(getApplicationContext(), ou, 3).show();
			for(int i=0;i<s.length;i++)
			{
				String []ss=s[i].split("#");
				st_id[i]=ss[0];
				st_nm[i]=ss[1];
			}
			ArrayAdapter<String> ad=new ArrayAdapter<String>(S_doubtsnrspns.this, android.R.layout.simple_spinner_item,st_nm);
			d.setAdapter(ad);
		}
		
		
		d.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				if(!d.getSelectedItem().toString().equals("select") && !d.getSelectedItem().toString().equals("error"))
				{
					staffid=st_id[arg2];
					list(staffid);
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		
		
		
		c.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				 if(!b.getText().toString().equals("select"))
				 {
				SoapObject obj=new SoapObject(soapclass.NAMESPACE, "Doubt");
				obj.addProperty("Staff_id",staffid);
				obj.addProperty("Stu_id",Login.uid);
				obj.addProperty("Doubt",b.getText().toString());
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj, "http://tempuri.org/Doubt");
				if(!ou.equals("") && !ou.equals("error"))
				{
					Intent i=new Intent(getApplicationContext(), S_doubtsnrspns.class) ;
					i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
				else
			     {
			    	 Toast.makeText(getApplicationContext(), "Enter doubts", 3).show();
			     }
			}
			}
		});
	}
void list(String val)
{
	SoapObject obj=new SoapObject(soapclass.NAMESPACE, "viewresponse");
	obj.addProperty("staffid",val);
	obj.addProperty("stid",Login.uid);
	soapclass sc=new soapclass();
	String ou=sc.Callsoap(obj, "http://tempuri.org/viewresponse");
	if(!ou.equals("error" ) && !ou.equals(""))
	{
		ArrayList<HashMap<String,String>> allist= new ArrayList<HashMap<String,String>>();
		String[] s1 = ou.split("@");
		for (int i=0;i<s1.length;i++){
			String[] s2= s1[i].split("#");
			HashMap<String, String> hmap=new HashMap<String, String>();
			hmap.put("a", s2[0]);
			hmap.put("b", s2[1]);
			
			allist.add(hmap);
		}
		ListAdapter lis=new SimpleAdapter(getApplicationContext(), allist, R.layout.response, new String[] {"a","b"}, new int[] {R.id.textView3,R.id.textView4});
		a.setAdapter(lis);
	}
}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.s_doubtsnrspns, menu);
		return true;
	}

}
