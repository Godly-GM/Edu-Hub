package com.example.education;

import java.util.ArrayList;
import java.util.HashMap;

import org.ksoap2.serialization.SoapObject;

import android.R.string;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

@SuppressLint("NewApi") public class S_dbt_ansr extends Activity {
EditText a,b;
Button c;
ListView d;
String did;
	@TargetApi(Build.VERSION_CODES.GINGERBREAD) @SuppressLint("NewApi") @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_s_dbt_ansr);
		 try
	    	{
	    		if (android.os.Build.VERSION.SDK_INT > 9) 
	    		{
	    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	    			StrictMode.setThreadPolicy(policy);
	    		}
	    	}
	    	catch(Exception e)
	    	{
	    		
	    	}
		a=(EditText)findViewById(R.id.editText1);
		b=(EditText)findViewById(R.id.editText2);
		c=(Button)findViewById(R.id.button1);
		d=(ListView)findViewById(R.id.listView1);
		
		SoapObject obj=new SoapObject(soapclass.NAMESPACE, "viewdoubt");
		obj.addProperty("staffid",Login.uid);
		soapclass sc=new soapclass();
		String ou=sc.Callsoap(obj, "http://tempuri.org/viewdoubt");
		if(!ou.equals("error" ) && !ou.equals(""))
		{
			ArrayList<HashMap<String,String>> allist= new ArrayList<HashMap<String,String>>();
			String[] s1 = ou.split("@");
			for (int i=0;i<s1.length;i++){
				String[] s2= s1[i].split("#");
				HashMap<String, String> hmap=new HashMap<String, String>();
				hmap.put("a", s2[0]);
				hmap.put("b", s2[1]);
				hmap.put("c", s2[2]);
				allist.add(hmap);
			}
			ListAdapter lis=new SimpleAdapter(getApplicationContext(), allist, R.layout.two, new String[] {"b","c"}, new int[] {R.id.textView3,R.id.textView4});
			d.setAdapter(lis);
		}
		
		
		d.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				HashMap<String, String> hmap=( HashMap<String, String>)arg0.getItemAtPosition(arg2);
				did=hmap.get("a");
				
				a.setText(hmap.get("c"));
			}
		});
		c.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				 if(!b.getText().toString().equals("select"))
				 {
				SoapObject obj=new SoapObject(soapclass.NAMESPACE, "UpdateDoubtreply");
				obj.addProperty("did",did);
				obj.addProperty("reply",b.getText().toString());
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj, "http://tempuri.org/UpdateDoubtreply");
				if(!ou.equals("") && !ou.equals("error"))
				{
					Intent i=new Intent(getApplicationContext(), S_dbt_ansr.class) ;
					i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			}
			
			else
		     {
		    	 Toast.makeText(getApplicationContext(), "Enter Reply", 3).show();
		     }	
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.s_dbt_ansr, menu);
		return true;
	}

}
