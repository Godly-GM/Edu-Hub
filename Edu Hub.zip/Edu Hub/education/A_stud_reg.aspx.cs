﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    Db_operation Db = new Db_operation();
    SendMail sm = new SendMail();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            MultiView1.SetActiveView(View1);


            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = " select * from students";
            DataGrid1.DataSource = Db.view(cmd);
            DataGrid1.DataBind();

            cmd.CommandText = "select ID,Department from dept";
            DropDownList1.DataSource = Db.view(cmd);
            DropDownList1.DataTextField = "Department";
            DropDownList1.DataValueField = "ID";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "Select");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        MultiView1.SetActiveView(View2);
        Button3.Visible = false;



        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select max(Stud_Id) from students";
        TextBox1.Text = Db.max_id(cmd).ToString();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        
    }
   
   
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = " update students set Stud_Name='" + TextBox2.Text + "',DOB='" + TextBox7.Text + "',Adress='" + TextBox3.Text + "',Gender='" + RadioButtonList1.Text + "',Phone='" + TextBox4.Text + "',Guardian='" + TextBox5.Text + "',Course='" + DropDownList1.SelectedValue + "',mail='" + TextBox8.Text + "' where Stud_Id='" + TextBox1.Text + "' ";
        Db.execute(cmd);

        MultiView1.SetActiveView(View1);
        cmd.CommandText = " select * from students";
        DataGrid1.DataSource = Db.view(cmd);
        DataGrid1.DataBind();
    }
    protected void DataGrid1_ItemCommand(object source, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Update")
        {

            MultiView1.SetActiveView(View2);
            Button2.Visible = false;
            Button3.Visible = true;

            Label2.Visible = false;
            Label3.Visible = false;
            Label4.Visible = false;
            Label5.Visible = false;
            TextBox9.Visible = false;
            TextBox10.Visible = false;
            TextBox11.Visible = false;
            DropDownList2.Visible = false;

            TextBox1.Text = e.Item.Cells[0].Text;
            TextBox2.Text = e.Item.Cells[1].Text;
            TextBox3.Text = e.Item.Cells[3].Text;
            TextBox4.Text = e.Item.Cells[6].Text;
            RadioButtonList1.Text = e.Item.Cells[4].Text;
            TextBox5.Text = e.Item.Cells[5].Text;
            DropDownList1.SelectedItem.Text = e.Item.Cells[7].Text;
            TextBox7.Text = e.Item.Cells[2].Text;
            TextBox8.Text = e.Item.Cells[8].Text;
        }
        else if (e.CommandName == "Delete")
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = " delete from students where Stud_id='" + e.Item.Cells[0].Text + "' ";
            Db.execute(cmd);

            MultiView1.SetActiveView(View1);
            cmd.CommandText = " select * from students";
            DataGrid1.DataSource = Db.view(cmd);
            DataGrid1.DataBind();

        }
    }

    protected void DataGrid1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "insert into students values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox7.Text + "','" + TextBox3.Text + "','" + RadioButtonList1.Text + "','" + TextBox5.Text + "','" + TextBox4.Text + "','" + DropDownList1.SelectedValue + "','" + TextBox8.Text + "','" + TextBox10.Text + "','" + DropDownList2.Text + "')";
        Db.execute(cmd);

        cmd.CommandText = "insert into login values('" + TextBox1.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "','student')";
        Db.execute(cmd);

        cmd.CommandText = "insert into login values('" + TextBox1.Text + "','" + TextBox10.Text + "','" + TextBox11.Text + "','parent')";
        Db.execute(cmd);

        sm.sendmail(TextBox10.Text,TextBox11.Text,"your password");

        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        RadioButtonList1.Text = "";
        TextBox5.Text = "";
        //TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = ""; 
        TextBox9.Text = "";
        TextBox10.Text = "";
        TextBox11.Text = "";


        MultiView1.SetActiveView(View1);
        cmd.CommandText = " select * from students";
        DataGrid1.DataSource = Db.view(cmd);
        DataGrid1.DataBind();
        Response.Write("<script>alert('Success')</script>");
    }
}