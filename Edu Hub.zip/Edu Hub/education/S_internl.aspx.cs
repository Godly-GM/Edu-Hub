﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    Db_operation db = new Db_operation();
    static int id;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select max(id) from internal ";
            id = db.max_id(cmd);

            cmd.CommandText = "select Stud_id from students";
            DropDownList5.DataSource = db.view(cmd);
            DropDownList5.DataTextField = "Stud_id";
            DropDownList5.DataValueField = "Stud_id";
            DropDownList5.DataBind();
            DropDownList5.Items.Insert(0, "Select Id");

            for (int i = 0; i <= 10; i++)
            {
                DropDownList3.Items.Add(i.ToString());
            }
            DropDownList3.Items.Insert(0,"select");

            cmd.CommandText = "select semester from dept ";
            DropDownList6.DataSource = db.view(cmd);
            DropDownList6.DataTextField = "Semester";
            DropDownList6.DataValueField = "semester";
            DropDownList6.DataBind();
        }
       

    }
    
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "insert into internal values('"+id+"','" + DropDownList5.Text + "','" + TextBox2.Text + "','"+DropDownList6.SelectedValue+"','" + DropDownList4.Text + "','" + TextBox3.Text + "','" + TextBox5.Text + "','" + DropDownList3.Text + "','" + TextBox6.Text + "')";
        db.execute(cmd);
        cmd.CommandText = "select max(id) from internal";
        id = db.max_id(cmd);
       
        TextBox2.Text = "";
        DropDownList4.Text = "";
        TextBox3.Text = "";
        TextBox5.Text = "";
        
        TextBox6.Text = "";

        cmd.CommandText = "select max(id) from internal ";
        id = db.max_id(cmd);
        Response.Write("<script>alert('Success')</script>");
    }
    protected void DropDownList5_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select Stud_Name from students where Stud_Id='"+DropDownList5.SelectedValue+"'";
        DataTable dt = db.view(cmd);
        TextBox2.Text=dt.Rows[0][0].ToString();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        int a, b, c, d;
        a = Convert.ToInt32(TextBox3.Text);
        b = Convert.ToInt32(TextBox5.Text);
        c = Convert.ToInt32(DropDownList3.Text);
        d = a + b + c;
        TextBox6.Text = d.ToString();
    }
    protected void TextBox6_TextChanged(object sender, EventArgs e)
    {
        
    }
}