﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    Db_operation Db = new Db_operation();
    static int id;
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select max(id) from notification";
        id = Db.max_id(cmd);
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "insert into notification values('" + id + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + DropDownList1.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "')";
        Db.execute(cmd);
        cmd.CommandText = "select max(id) from notification";
        id = Db.max_id(cmd);
        TextBox1.Text = "";
        TextBox2.Text = ""; 
        
        TextBox3.Text = "";
        TextBox4.Text = "";
       
        Response.Write("<script>alert('Success')</script>");
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {

    }
}