﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    Db_operation Db = new Db_operation();
    static int id;
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select max(id) from dept";
        id = Db.max_id(cmd);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select max(id) from dept";
        id = Db.max_id(cmd);
        cmd.CommandText = "insert into dept values('" + id + "','" + TextBox1.Text + "','"+TextBox2.Text+"')";
        Db.execute(cmd);

        TextBox1.Text = "";
        TextBox2.Text = "";

        Response.Write("<script>alert('Success')</script>");

    }
}