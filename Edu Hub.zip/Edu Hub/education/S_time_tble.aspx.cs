﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
     Db_operation db = new Db_operation();
    static int id;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select max(id) from time_table ";
            id = db.max_id(cmd);

            cmd.CommandText = "select ID,Department from dept";
            DropDownList1.DataSource = db.view(cmd);    
            DropDownList1.DataTextField = "Department";
            DropDownList1.DataValueField = "ID";
            DropDownList1.DataBind();

            cmd.CommandText = "select semester from dept ";
            DropDownList3.DataSource = db.view(cmd);
            DropDownList3.DataTextField = "Semester";
            DropDownList3.DataValueField = "semester";
            DropDownList3.DataBind();

            cmd.CommandText = "select Staff_Id,Staff_Name from staff";
            DropDownList2.DataSource = db.view(cmd);
            DropDownList2.DataTextField = "Staff_Name";
            DropDownList2.DataValueField = "Staff_Id";
            DropDownList2.DataBind();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "insert into time_table values('"+id+"','" + DropDownList1.SelectedValue + "','"+DropDownList3.SelectedValue+"','" + DropDownList2.SelectedValue + "','" + TextBox3.Text + "','" + TextBox4.Text + "')";
        db.execute(cmd);
        cmd.CommandText = "select max(id) from time_table";
        id = db.max_id(cmd);

        
        TextBox3.Text = "";
        TextBox4.Text = "";

        Response.Write("<script>alert('Success')</script>");
    }
}