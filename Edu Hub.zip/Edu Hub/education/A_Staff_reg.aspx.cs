﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    Db_operation Db = new Db_operation();
   
    protected void Page_Load(object sender, EventArgs e)
    {
        MultiView1.SetActiveView(View1);


        SqlCommand cmd = new SqlCommand();
        

        cmd.CommandText = " select * from staff";
        DataGrid1.DataSource = Db.view(cmd);
        DataGrid1.DataBind();



    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        MultiView1.SetActiveView(View2);
        Button3.Visible = false;

      

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select max(Staff_Id) from staff";
        TextBox1.Text = Db.max_id(cmd).ToString();


    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "insert into staff values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + RadioButtonList1.Text + "')";
        Db.execute(cmd);
        cmd.CommandText = "insert into login values('" + TextBox1.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','staff')";
        Db.execute(cmd);
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";

        MultiView1.SetActiveView(View1);
        cmd.CommandText = " select * from staff";
        DataGrid1.DataSource = Db.view(cmd);
        DataGrid1.DataBind();
        Response.Write("<script>alert('Success')</script>");
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void DataGrid1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DataGrid1_ItemCommand(object source, DataGridCommandEventArgs e)
    {


        if (e.CommandName == "update")
        {

            MultiView1.SetActiveView(View2);
            Button2.Visible = false;
            Button3.Visible = true;
            TextBox6.Visible = false;
            Label1.Visible = false;

            TextBox1.Text=e.Item.Cells[0].Text;
            TextBox2.Text = e.Item.Cells[1].Text;
            TextBox3.Text = e.Item.Cells[2].Text;
            TextBox4.Text = e.Item.Cells[3].Text;
            TextBox5.Text = e.Item.Cells[4].Text;
            RadioButtonList1.Text = e.Item.Cells[5].Text;
            TextBox6.Text = e.Item.Cells[6].Text;
        }
        else if (e.CommandName == "delete")
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = " delete from staff where Staff_id='"+e.Item.Cells[0].Text+"' ";
            Db.execute(cmd);

            MultiView1.SetActiveView(View1);
            cmd.CommandText = " select * from staff";
            DataGrid1.DataSource = Db.view(cmd);
            DataGrid1.DataBind();
          
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = " update staff set Staff_Name='"+TextBox2.Text+"',Phone='"+TextBox3.Text+"',Qualification='"+TextBox4.Text+"',Mail='"+TextBox5.Text+"',Gender='"+RadioButtonList1.Text+"' where Staff_id='" + TextBox1.Text + "' ";
        Db.execute(cmd);

        MultiView1.SetActiveView(View1);
        cmd.CommandText = " select * from staff";
        DataGrid1.DataSource = Db.view(cmd);
        DataGrid1.DataBind();
    }
}