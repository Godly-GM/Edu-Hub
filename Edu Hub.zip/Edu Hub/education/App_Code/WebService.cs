﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class WebService : System.Web.Services.WebService
{
    Db_operation db = new Db_operation();
    static string point,ss;
    static double pr, hf, hff, tpr,tw;
    public WebService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string login_act(string unm, string pass)
    {
        string s = "";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select * from login where user_name='" + unm + "' and password='" + pass + "'";
        DataTable dt = db.view(cmd);
        if (dt.Rows.Count > 0)
        {
            s = dt.Rows[0][0].ToString() + "#" + dt.Rows[0][3].ToString();
        }
        else
        {
            s = "error";
        }
        return s;
    }

    [WebMethod]
    public string forgot_act(string ml)
    {
        string s = "";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select * from login where user_name='" + ml + "' and type='parent'";
        DataTable dt = db.view(cmd);
        if (dt.Rows.Count > 0)
        {
            s = dt.Rows[0][2].ToString();
            SendMail sm = new SendMail();
            sm.sendmail(ml, s, "Hi, Your Password: ");
                
        }
        else
        {
            s = "error";
        }
        return s;
    }

    [WebMethod]
    public string complaint_act(string parent_id, string complaint)
    {
        string s = "";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select max(Comp_id) from complaint";
        int id = db.max_id(cmd);
        cmd.CommandText = "insert into complaint values('" + id + "','" + parent_id + "','" + System.DateTime.Now.ToShortDateString() + "','" + complaint + "','pending')";
        try
        {
            db.execute(cmd);
            s = "success";
        }
        catch
        {
            s = "error";
        }
        return s;

    }
    [WebMethod]
    public string compview_act(string parent_id)
    {
        string s = "";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select * from complaint Where parent_id='" + parent_id + "'";
        DataTable dt = db.view(cmd);
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                s += dr[2].ToString() + "#" + dr[3].ToString() + "#" + dr[4].ToString() + "@";
            }
        }
        else
        {
            s = "error";
        }
        return s;


    }
    [WebMethod]
    public string Alert_act(string staff_id, string alert,string sem)
    {
        string s = "";
        SqlCommand cmd = new SqlCommand();

        cmd.CommandText = "select max(Alert_id) from Alert";
        int id = db.max_id(cmd);
        cmd.CommandText = "insert into Alert values('" + id + "','" + staff_id + "','" + alert + "','" + System.DateTime.Now.ToShortDateString() + "')";
        try
        {
            db.execute(cmd);
            s = "success";
        }
        catch
        {
            s = "error";
        }

        cmd.CommandText = "select * from students where Semester='"+sem+"'";
        DataTable dt = db.view(cmd);
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                string parentid = dr[0].ToString();
                SqlCommand cm = new SqlCommand();
                cm.CommandText = "insert into Alert_sub values ('" + id + "','" + parentid + "','pending')";
                db.execute(cm);
            }
        }
        else
        {
            s = "error";
        }

        return s;
    }
     [WebMethod]
    public string Alertview_act(string pid)
    {
        string s = "";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT  Alert.date, Alert.alert FROM  Alert INNER JOIN   Alert_sub ON Alert.Alert_id = Alert_sub.Alert_id where  Alert_sub.Parent_id ='"+pid+"'";
        DataTable dt = db.view(cmd);
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                s += dr[0].ToString() + "#" + dr[1].ToString()+ "@";



            }
        }
        else
        {
            s = "error";
        }
        return s;


    }

     [WebMethod]
     public string Parent_alertview_act(string pid)
     {
         string s = "";
         SqlCommand cmd = new SqlCommand();
         cmd.CommandText = "SELECT        Alert.Alert_id, Alert.date, Alert.alert FROM    Alert INNER JOIN  Alert_sub ON Alert.Alert_id = Alert_sub.Alert_id";
         DataTable dt = db.view(cmd);
         if (dt.Rows.Count > 0)
         {
             foreach (DataRow dr in dt.Rows)
             {
              string val  = dr[1].ToString() + "  Alert:" + dr[2].ToString();
                 string sts = dr[0].ToString();
                  SqlCommand cm = new SqlCommand();
                  cm.CommandText = "SELECT  * from Alert_sub where Alert_id='"+sts+"' and Parent_id='"+pid+"' and status='pending' ";
                 DataTable dtt = db.view(cmd);
                 if (dtt.Rows.Count > 0)
                 {
                     s = val;
                     SqlCommand cmd1 = new SqlCommand();
                     cmd1.CommandText = "update Alert_sub set status='done' where Alert_id='" + sts + "' and Parent_id='" + pid + "'";
                     db.execute(cmd1);
                 }
                 else
                 {
                     s = "error";
                 }
             }
         }
         else
         {
             s = "error";
         }
         return s;


     }





    [WebMethod]
    public string feedback_id(string User_id, string feedback)
    {
        string s = "";
        SqlCommand cmd = new SqlCommand();

        cmd.CommandText = "select max(feedback_id) from feedback";
        int id = db.max_id(cmd);
        cmd.CommandText = "insert into feedback values('" + id + "','" + User_id + "','" + feedback + "')";
        try
        {
            db.execute(cmd);
            s = "success";
        }
        catch
        {
            s = "error";
        }
        return s;
    }
     [WebMethod]
    public string feedview_act()
    {
        string s = "";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT         students.Guardian,Feedback.feedback FROM  Feedback INNER JOIN students ON Feedback.User_id = students.Stud_Id";
        DataTable dt = db.view(cmd);
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                s += dr[0].ToString() + "#" + dr[1].ToString() + "@";
            }
        }
        else
        {
            s = "error";
        }
        return s;


    }

    [WebMethod]
    public string event_act()
    {
        string s = "";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select * from event";
        DataTable dt = db.view(cmd);
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                s += dr[0].ToString() + "#" + dr[1].ToString() + "#" + dr[2].ToString() + "#" + dr[3].ToString() + "#" + dr[4].ToString() + "@";
            }
        }
        else
        {
            s = "error";
        }
        return s;
    }
    [WebMethod]
    public string notification_act()
    {
        string s = "";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select * from notification ";
        DataTable dt = db.view(cmd);
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                s += dr[0].ToString() + "#" + dr[1].ToString() + "#" + dr[2].ToString() + "#" + dr[3].ToString() + "#" + dr[4].ToString() + "#" + dr[5].ToString() + "@";
            }
        }
        else
        {
            s = "error";
        }
        return s;

    }
    [WebMethod]
    public string Attendance_act(string Stu_id, string Status, string Hour, string Staff_id)
    {
        string s = "";
         SqlCommand cm = new SqlCommand();
         cm.CommandText = "select * from Attendance where Stu_id='"+Stu_id+"' and Date='" + System.DateTime.Now.ToShortDateString() + "' and ((Hour1='" + Hour + "') or (Hour2='" + Hour + "')  or (Hour3='" + Hour + "')  or (Hour4='" + Hour + "')  or (Hour5='" + Hour + "') )";
        DataTable dt12 = db.view(cm);
        if (dt12.Rows.Count > 0)
        {
            s = "Already Submitted";
        }
        else
        {
            SqlCommand cmd = new SqlCommand();
            if (Status == "absent")
            {
                point = "0";
            }
            else if (Status == "present")
            {
                point = "1";
            }

            cmd.CommandText = "select * from Attendance where Stu_id='" + Stu_id + "' and Date='" + System.DateTime.Now.ToShortDateString() + "'";
            DataTable dt1 = db.view(cmd);
            if (dt1.Rows.Count > 0)
            {


                if (Hour == "1")
                {
                    cmd.CommandText = "update Attendance set Hour1='" + point + "' where  Stu_id='" + Stu_id + "' and Date='" + System.DateTime.Now.ToShortDateString() + "' ";

                }

                else if (Hour == "2")
                {
                    cmd.CommandText = "update Attendance set Hour2='" + point + "' where  Stu_id='" + Stu_id + "' and Date='" + System.DateTime.Now.ToShortDateString() + "' ";

                }
                else if (Hour == "3")
                {
                    cmd.CommandText = "update Attendance set Hour3='" + point + "' where  Stu_id='" + Stu_id + "' and Date='" + System.DateTime.Now.ToShortDateString() + "' ";

                }

                else if (Hour == "4")
                {
                    cmd.CommandText = "update Attendance set Hour4='" + point + "' where  Stu_id='" + Stu_id + "' and Date='" + System.DateTime.Now.ToShortDateString() + "' ";

                }

                else if (Hour == "5")
                {
                    cmd.CommandText = "update Attendance set Hour5='" + point + "' where  Stu_id='" + Stu_id + "' and Date='" + System.DateTime.Now.ToShortDateString() + "' ";

                }
                try
                {
                    db.execute(cmd);
                    s = "success";
                }
                catch
                {
                    s = "error";
                }
                cmd.CommandText = "select Hour1,Hour2,Hour3,Hour4,Hour5 from Attendance where Stu_id='" + Stu_id + "' and Date='" + System.DateTime.Now.ToShortDateString() + "'";
                DataTable dt = db.view(cmd);
                if (dt.Rows.Count > 0)
                {
                    int h1 = Convert.ToInt32(dt.Rows[0][0].ToString());
                    int h2 = Convert.ToInt32(dt.Rows[0][1].ToString());
                    int h3 = Convert.ToInt32(dt.Rows[0][2].ToString());
                    int h4 = Convert.ToInt32(dt.Rows[0][3].ToString());
                    int h5 = Convert.ToInt32(dt.Rows[0][4].ToString());
                    int hh = h1 + h2 + h3 + h4 + h5;

                    if (hh > 2)
                    {
                        ss = "halfday";
                    }
                    else if (hh < 3)
                    {
                        ss = "absent";
                    }
                    else if (hh > 4)
                    {
                        ss = "present";
                    }
                }
                cmd.CommandText = "update Attendance set Status='" + ss + "' where  Stu_id='" + Stu_id + "' and Date='" + System.DateTime.Now.ToShortDateString() + "' ";
                db.execute(cmd);
            }
            else
            {
                cmd.CommandText = "select max(id) from Attendance";
                int id = db.max_id(cmd);
                cmd.CommandText = "insert into Attendance values('" + id + "','" + Stu_id + "','" + System.DateTime.Now.ToShortDateString() + "','" + Staff_id + "','0','0','0','0','0','pending')";
                db.execute(cmd);
            }


        }
        return s;

    }


    [WebMethod]

    public string students(string Semester)
    {
        string s = "";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select * from students Where Semester='"+Semester+"'";
        DataTable dt = db.view(cmd);
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                s += dr[0].ToString() + "#" + dr[1].ToString() + "@";
            }
        }
        else
        {
            s = "error";
        }
        return s;
    }
    // [WebMethod]

    //public string Attendance(string stu_id)
    //{
    //    string s = "";
    //    SqlCommand cmd = new SqlCommand();
    //    cmd.CommandText = "select * from Attendance";
    //    DataTable dt = db.view(cmd);
    //    if (dt.Rows.Count > 0)
    //    {
    //        foreach (DataRow dr in dt.Rows)
    //        {
    //            s += dr[0].ToString() + "#" + dr[1].ToString() + "@";
    //        }
    //    }
    //    else
    //    {
    //        s = "error";
    //    }
    //    return s;
    //}


    [WebMethod]

    public string staff()
    {
        string s = "";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select * from staff";
        DataTable dt = db.view(cmd);
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                s += dr[0].ToString() + "#" + dr[1].ToString() + "@";
            }
        }
        else
        {
            s = "0#error@";
        }
        return "0#select@"+s;
    }


     [WebMethod]
    public string Doubt(string Stu_id, string Doubt, string Staff_id)
    {
        string s = "";
        SqlCommand cmd = new SqlCommand();

        cmd.CommandText = "select max(Id) from Doubt";
        int id = db.max_id(cmd);
        cmd.CommandText = "insert into Doubt values('" + id + "','" + Stu_id + "','" + Doubt + "','" + Staff_id + "','pending')";
        try
        {
            db.execute(cmd);
            s = "success";
        }
        catch
        {
            s = "error";
        }
        return s;
    }


     [WebMethod]

     public string viewdoubt(string staffid)
     {
         string s = "";
         SqlCommand cmd = new SqlCommand();
         cmd.CommandText = "select * from Doubt where Staff_id='"+staffid+"' and Reply='pending'";
         DataTable dt = db.view(cmd);
         if (dt.Rows.Count > 0)
         {
             foreach (DataRow dr in dt.Rows)
             {
                 s += dr[0].ToString() + "#" + dr[1].ToString() + "#" + dr[2].ToString() + "@";
             }
         }
         else
         {
             s = "error";
         }
         return s;
     }

     [WebMethod]
     public string UpdateDoubtreply(string did, string reply)
     {
         string s = "";
         SqlCommand cmd = new SqlCommand();
         cmd.CommandText = "update Doubt set Reply='" + reply + "' where Id='" + did + "'";
         try
         {
             db.execute(cmd);
             s = "success";
         }
         catch
         {
             s = "error";
         }
         return s;
     }



     [WebMethod]
     public string viewresponse(string staffid, string stid)
     {
         string s = "";
         SqlCommand cmd = new SqlCommand();
         cmd.CommandText = "select * from Doubt where Staff_id='" + staffid + "' and Stu_id='" + stid + "'";
         DataTable dt = db.view(cmd);
         if (dt.Rows.Count > 0)
         {
             foreach (DataRow dr in dt.Rows)
             {
                 s += dr[2].ToString() + "#" + dr[4].ToString() + "@";
             }
         }
         else
         {
             s = "error";
         }
         return s;
     }

     [WebMethod]
     public string timetable(string stud_id)
     {
         string s = "";
         SqlCommand cmd = new SqlCommand();
         cmd.CommandText = "select Course,semester from students where Stud_Id='" + stud_id + "'";
         DataTable dt = db.view(cmd);
         if (dt.Rows.Count > 0)
         {
             cmd.CommandText = "select s.Staff_Name,t.Subject,t.Hour from time_table t,staff s where t.Staff=s.Staff_Id and t.Dept_id='"+dt.Rows[0][0]+"' and t.semester='"+dt.Rows[0][1]+"' order by t.Hour";
             DataTable dtt = db.view(cmd);

             if (dt.Rows.Count > 0)
             {

                 foreach (DataRow dr in dtt.Rows)
                 {
                     s += dr[0].ToString() + "#" + dr[1].ToString() +"#"+dr[2].ToString()+"@";
                 }
             }
         }
         else
         {
             s = "error";
         }
         return s;
     }


     [WebMethod]
     public string viewreinternal( string sid)
     {
         string s = "";
         SqlCommand cmd = new SqlCommand();
         cmd.CommandText = "select * from internal where Stu_id='"+sid+"'";
         DataTable dt = db.view(cmd);
         if (dt.Rows.Count > 0)
         {
             foreach (DataRow dr in dt.Rows)
             {
                 s += dr[4].ToString()+"#"+dr[5].ToString()+"#"+dr[6].ToString()+"#"+dr[7].ToString()+"#"+dr[8].ToString()+"@";
               
                 
             }
         }
         else
         {
             s = "error";
         }
         return s;
     }
     [WebMethod]
     public string slct_date()
     {
         string s = "";
         SqlCommand cmd = new SqlCommand();
         cmd.CommandText = "select distinct Date from Attendance";
         DataTable dt = db.view(cmd);
         if (dt.Rows.Count > 0)
         {
             foreach (DataRow dr in dt.Rows)
             {
                 s += dr[0].ToString() + "#";
             }
         }
         else
         {
             s = "error";
         }
         return s;
     }
     [WebMethod]
     public string view_atten(string stuid,string from_date,string last_date)
     {
         string s = "";
         //DateTime fd = Convert.ToDateTime(from_date);
         //DateTime ld = Convert.ToDateTime(last_date);
         SqlCommand cmd = new SqlCommand();
         cmd.CommandText = "SELECT Date,Status FROM Attendance WHERE (Date BETWEEN '" + from_date + "' AND '" + last_date + "') AND Stu_id='"+stuid+"' ";
         DataTable dt = db.view(cmd);
         if (dt.Rows.Count > 0)
         {
             foreach (DataRow dr in dt.Rows)
             {
                 s += dr[0].ToString() + "#"+dr[1].ToString()+"@";
             }
         }
         else
         {
             s = "error";
         }
         return s;
     }
     [WebMethod]
     public string view_atten_percent(string stuid)
     {
         string s = "";

         SqlCommand cmd = new SqlCommand();
         cmd.CommandText = "select count(Stu_id) from Attendance where Stu_id ='" + stuid + "'";
         try
         {
             DataTable dt = db.view(cmd);
             if (dt.Rows.Count > 0)
             {
                tw =Convert .ToDouble (dt.Rows[0][0].ToString());
             }

             cmd.CommandText = "select count(Status) from Attendance where Status='present' and Stu_id='"+stuid+"'";
             DataTable dt2 = db.view(cmd);
             if (dt2.Rows.Count > 0)
             {
                 pr = Convert.ToDouble(dt2.Rows[0][0].ToString());
             }

             cmd.CommandText = "select count(Status) from Attendance where Status='halfday' and Stu_id='" + stuid + "'";
             DataTable dt3 = db.view(cmd);
             if (dt3.Rows.Count > 0)
             {
                 hf = Convert.ToDouble(dt3.Rows[0][0].ToString());
             }
            
                 hff = hf *0.5;
             
             tpr = pr + hff;
             s = ((tpr / tw) * 100).ToString()+"%";

         }
         catch
         {
             s = "error";
         }
         return s;
     }
    

}























