﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// Summary description for Db_operation
/// </summary>
public class Db_operation
{
    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-SEV4CGU\SQLEXPRESS;Initial Catalog=C:\USERS\PC9\DOCUMENTS\EDUCATION.MDF;Persist Security Info=True;User ID=education1;Password=user123");

	public Db_operation()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public void execute(SqlCommand cmd)
    {
        cmd.Connection = con;
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
            con.Close();
        }
    }
    public DataTable view(SqlCommand cmd)
    {
        cmd.Connection = con;
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds.Tables[0];
    }

    public int max_id(SqlCommand cmd)
    {
        cmd.Connection = con;
        int i;

        try
        {
            con.Open();
            i = Convert.ToInt32(cmd.ExecuteScalar()) + 1;
        }
        catch
        {
            i = 1;
        }
        con.Close();
        return i;
    }
}
