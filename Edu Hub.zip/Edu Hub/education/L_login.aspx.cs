﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    Db_operation Db = new Db_operation();
    SqlCommand cmd = new SqlCommand();
    static int id;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select * from login where user_name='"+TextBox1.Text+"' and password='"+TextBox2.Text+"'";
        DataTable dt = Db.view(cmd);
        if (dt.Rows.Count > 0)
        {
            string type=dt.Rows[0][3].ToString();

            if (type == "admin")
            {
                Response.Redirect("A_Home.aspx");
            }
            else if (type == "staff")
            {
                Response.Redirect("S_Home.aspx");

            }
        }
        Response.Write("<script>alert('Invalid Username and Password')</script>");
        
    }
}