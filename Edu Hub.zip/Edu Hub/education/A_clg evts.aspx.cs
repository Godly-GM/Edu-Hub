﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class _Default : System.Web.UI.Page
{
    Db_operation db = new Db_operation();
    static int id;
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select max(id) from event";
        id = db.max_id(cmd);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd=new SqlCommand();
        cmd.CommandText="insert into event values('"+id+"','"+TextBox1.Text+"','"+TextBox2.Text+"','"+TextBox3.Text+"','"+TextBox4.Text+"')";
        db.execute(cmd);

        cmd.CommandText = "select max(id) from event";
        id = db.max_id(cmd);
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";

        Response.Write("<script>alert('Success')</script>");
    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {

    }
}
 